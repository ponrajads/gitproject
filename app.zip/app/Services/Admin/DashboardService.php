<?php
declare(strict_types=1);
namespace App\Services\Admin;

// Request
use Illuminate\Http\Request;

//Controller
use App\Http\Controllers\Controller;

//Models
use App\Models\User;
use App\Models\Packages;
use App\Models\Events;

//Facades
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Carbon\Carbon;

class DashboardService 
{
   /**
   * Return get User.
   *
   * @method getUserByUserID
   *
   * @param integer $userUID
   *
   * @return User;
   */

    public static function getUserByUserID(int $userUID):? User
    {
        return User::where('id','=',$userUID)->first();
       
    }  

   /**
   * Return get Packages.
   *
   * @method getPackageByPackID
   *
   * @param integer $packid
   *
   * @return Packages;
   */

    public static function getPackageByPackID(int $packid):? Packages
    {
        return Packages::where('id','=',$packid)->first();
    } 

   /**
   * Return get Events.
   *
   * @method getUpcomingDataByUserID
   *
   * @param integer $userUID
   *
   * @return integer;
   */


    public static function getUpcomingDataByUserID(int $userUID):?int
    {
        return Events::where('userid',$userUID)->where('startdate','>',Carbon::now())->count();
    } 

    
   /**
   * Return get Events.
   *
   * @method getCompletedDataByUserID
   *
   * @param integer $userUID
   *
   * @return integer;
   */

    public static function getCompletedDataByUserID(int $userUID):?int
    {
        return Events::where('userid',$userUID)->where('enddate','>',Carbon::now())->count();
    } 
    
    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

}
