<?php
declare(strict_types=1);
namespace App\Services\Event;

// Request
use Illuminate\Http\Request;

//Controller
use App\Http\Controllers\Controller;

//Models
use App\Models\Events;
use App\Models\Account;
use App\Models\Players;
use App\Models\User;
use App\Models\Packages;
use App\Models\Registrations;
use App\Models\Medical;
use App\Models\CallRoom;
use App\Models\Complimentary;
use App\Models\FoodCourt;
use App\Models\OnField;
use App\Models\Podium;
use App\Models\PlayerMaster;
use App\Models\EventMaster;

//Facades
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Carbon\Carbon;

class EventService
{
   /**
   * Return get User.
   *
   * @method getUserByUserID
   *
   * @param int $userUID
   *
   * @return User;
   */

  public static function getUserByUserID(int $userUID):?User
  {
      return User::where('id','=',$userUID)->first();
     
  }  

   /**
   * Return get Event List.
   *
   * @method getAllEventsList
   *
   * @param integer $userUID
   *
   * @return Collection;
   */

    public static function getAllEventsList(int $userUID):? Collection
    {

        return Events::where('userid',$userUID)->orderBy('id', 'DESC')->get();
    }

   /**
   * Return get Event Details.
   *
   * @method getEventByEventID
   *
   * @param integer $eventid
   *
   * @return Events;
   */

    public static function getEventByEventID(int $eventid):?Events
    {

        return Events::where('id',$eventid)->first();
    }

   /**
   * Return event id.
   *
   * @method createEventbyRequest
   *
   * @param Request $request
   *
   * @param string $eventlogo_name
   * 
   * @param User $userdata
   * 
   * @return integer;
   */


  public static function createEventbyRequest(Request $request,string $eventlogo_name,User $userdata):?int
  {

          $event = new Events();
          $event->name = $request->input('eventname');
          $event->location = $request->input('address');
          $event->startdate = $request->input('startdate');
          $event->enddate = $request->input('enddate');
          $event->logo = $eventlogo_name;
          $event->userid = $request->input('uid');
          $event->save();
     
          $eventuid = Events::max('id');

          $destinationQRPath = storage_path('app/public/data/playerslist/qrcode/');
          $qrimage = \QrCode::format('png')->size(100)->errorCorrection('H')
          ->generate((string)$eventuid,$destinationQRPath.$eventuid . '.png');

          $qrName=$eventuid.'.png';

          $evntcnt = $userdata->eventcount - 1;
          $update = Events::where('id',$eventuid)->update(['formQR' => $qrName]);
          $updateuser = User::where('id',$request->input('uid'))->update(['eventcount' => $evntcnt]);

          return $eventuid;
  }

   /**
   * Return Credentials.
   *
   * @method getCredentialsByEventID
   *
   * @param integer $eventid
   * 
   * @param integer $module_id
   *
   * @return Collection;
   */

    public static function getCredentialsByEventID(int $eventid,int $module_id):? Collection
    {

        return Account::where('eventid',$eventid)
        ->where('moduleid',$module_id)
        ->get();
    }

   /**
   * Return Registration Data.
   *
   * @method getRegDataByEventID
   *
   * @param integer $eventid
   *
   * @return Collection;
   */


    public static function getRegDataByEventID(int $eventid):? Collection
    {

        return Registrations::join('players','players.id','=','registrations.playersid')
		->select(DB::raw("(SELECT eventName FROM eventmaster WHERE id = registrations.eventCategoryID LIMIT 1) as eventName"),DB::raw("(SELECT id FROM eventmaster WHERE id = registrations.eventCategoryID LIMIT 1) as eventcategid"),'players.*','registrations.*')
        ->where('registrations.serviceid',1)
        ->where('registrations.eventid',$eventid)
        ->get();
    }

   /**
   * Return Registration Abscent Data.
   *
   * @method getRegAbscentDataByEventID
   *
   * @param integer $eventid
   *
   * @return Registrations;
   */

    public static function getRegAbscentDataByEventID(int $eventid):? Registrations
    {

        return Registrations::where('registrations.serviceid',1)
        ->where('registrations.eventid',$eventid)
		->select(DB::raw('GROUP_CONCAT(playersid) as playersid'))
        ->first();
    }

   /**
   * Return get Registration Abscent Data.
   *
   * @method getRegAbscentDataByPlayerID
   *
   * @param integer $eventid
   * 
   * @param integer $playersid
   *
   * @return Collection;
   */

    public static function getRegAbscentDataByPlayerID(int $eventid,int $playersid):? Collection
    {

        return DB::select( DB::raw("select * from `players` where `players`.`serviceid` = 1 and `players`.`eventid` = $eventid and `players`.`id` not in ($playersid)"));
    }

   /**
   * Return get Medical data.
   *
   * @method getMedicalDataByEventID
   *
   * @param integer $eventid
   *
   * @return Collection;
   */

    public static function getMedicalDataByEventID(int $eventid):? Collection
    {

        return Medical::join('players','players.id','=','medical.playersid')
		->select(DB::raw("(SELECT eventName FROM eventmaster WHERE id = medical.eventCategoryID LIMIT 1) as eventName"),DB::raw("(SELECT id FROM eventmaster WHERE id = medical.eventCategoryID LIMIT 1) as eventcategid"),'players.*','medical.*')
        ->where('medical.serviceid',2)
        ->where('medical.eventid',$eventid)
        ->get();
    }

   /**
   * Return get CallRoom Data.
   *
   * @method getCallRoomDataByEventID
   *
   * @param integer $eventid
   *
   * @return Collection;
   */

    public static function getCallRoomDataByEventID(int $eventid):? Collection
    {

        return CallRoom::join('players','players.id','=','callroom.playersid')
		->select(DB::raw("(SELECT eventName FROM eventmaster WHERE id = callroom.eventCategoryID LIMIT 1) as eventName"),DB::raw("(SELECT id FROM eventmaster WHERE id = callroom.eventCategoryID LIMIT 1) as eventcategid"),'players.*','callroom.*')
        ->where('callroom.serviceid',3)
        ->where('callroom.eventid',$eventid)
        ->get();
    }

   /**
   * Return get On Field Data.
   *
   * @method getOnFieldDataByEventID
   *
   * @param integer $eventid
   *
   * @return Collection;
   */

    public static function getOnFieldDataByEventID(int $eventid):?Collection
    {

        return OnField::join('players','players.id','=','onfield.playersid')
        ->where('onfield.serviceid',4)
        ->where('onfield.eventid',$eventid)
        ->get();
    }

   /**
   * Return get Podium Data.
   *
   * @method getPodiumDataByEventID
   *
   * @param integer $eventid
   *
   * @return Collection;
   */

    public static function getPodiumDataByEventID(int $eventid):? Collection
    {

        return 	Podium::join('players','players.id','=','podium.playersid')
        ->where('podium.serviceid',5)
        ->where('podium.eventid',$eventid)
        ->get();
    }

   /**
   * Return get Food Court Data.
   *
   * @method getFoodCourtDataByEventID
   *
   * @param integer $eventid
   *
   * @return Collection;
   */

    public static function getFoodCourtDataByEventID(int $eventid):?Collection
    {

        return FoodCourt::join('players','players.id','=','foodcourt.playersid')
        ->where('foodcourt.serviceid',6)
        ->where('foodcourt.eventid',$eventid)
        ->get();
    }

   /**
   * Return get Complimentary data.
   *
   * @method getComplimentaryDataByEventID
   *
   * @param integer $eventid
   *
   * @return Collection;
   */

    public static function getComplimentaryDataByEventID(int $eventid):? Collection{

        return 	Complimentary::join('players','players.id','=','complimentary.playersid')
        ->where('complimentary.serviceid',7)
        ->where('complimentary.eventid',$eventid)
        ->get();
    }

       /**
   * Return get All Events.
   *
   * @method getAllEvents
   *
   * @return Collection;
   */

    public static function getAllEvents():?Collection
    {
        return 	EventMaster::all();
    }
}
