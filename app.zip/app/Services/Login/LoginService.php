<?php

declare(strict_types=1);

namespace App\Services\Login;
// Request
use Illuminate\Http\Request;
//Controller
use App\Http\Controllers\Controller;
//Facades
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class LoginService
{
   
}
