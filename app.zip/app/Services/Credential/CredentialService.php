<?php

declare(strict_types=1);
namespace App\Services\Credential;

// Request
use Illuminate\Http\Request;

//Controller
use App\Http\Controllers\Controller;

//Models
use App\Models\Account;
use App\Models\Events;
use App\Models\User;

//Facades
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Carbon\Carbon;
use Qrcode;

class CredentialService
{
    /**
   * Return get Event.
   *
   * @method getUserByEventID
   *
   * @param integer $eventid
   *
   * @return Events;
   */

  public static function getUserByEventID(int $eventid):? Events
    {
        return Events::where('id',$eventid)->first();

    }


    /**
   * Return Account ID.
   *
   * @method createRegAccount
   *
   * @param Request $request
   * 
   * @param string $username
   * 
   * @param int $moduleid
   *
   * @return integer;
   */

  public static function createAccount(Request $request,string $username,int $moduleid):? int
  {
        $account = new Account();
        $account->eventid = $request->input('eventid');
        $account->username = $username;
        $account->password = $request->input('password');
        $account->moduleid = $moduleid;
        $account->status = 1;
        $account->createdby = $request->input('uid');
        $account->save();
        $lastinsertid = $account->id;
        $destinationQRPath = storage_path('app/public/data/credentialslist/qrcode/');
          
        $qrimage =\QrCode::format('png')->size(100)->errorCorrection('H')
        ->generate((string)$lastinsertid,$destinationQRPath."id_".$lastinsertid."_".time() . '.png');
        
        $qrName="id_".$lastinsertid."_".time().'.png';
        
        Account::where('id',$lastinsertid)->update(['qrcode' => $qrName]);
        return $account->id;

  }
   
}
