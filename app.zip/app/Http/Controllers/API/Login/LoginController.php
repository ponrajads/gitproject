<?php
declare(strict_types=1);
namespace App\Http\Controllers\API\Login;

//Request
use Illuminate\Http\Request;
use App\Http\Requests\Login\LoginRequest;

// Response
use Illuminate\Http\Response;
use Illuminate\Http\JsonResponse;

//Controller
use App\Http\Controllers\Controller;

//Models
use App\Models\User; 
use App\Models\Players; 

//Services
use App\Services\Login\LoginService;

// Exceptions
use Exception;
use App\Exceptions\CustomModelNotFoundException;
use App\Exceptions\CustomLibraryException;

//Others
use Illuminate\Support\Facades\Auth; 
use Carbon\Carbon;
use Hash;

/**
 * @OA\Get(
 *     path="/backend",
 *     @OA\Response(response="200", description="Display a listing of projects.")
 * )
 */

class LoginController extends Controller
{

    public function __construct(LoginService $service)
    {
        $this->service = $service;
    }
    public $successStatus = 200;
    /**
        * @OA\Post(
        * path="/api/login",
        * operationId="authLogin",
        * tags={"Login"},
        * summary="User Login",
        * description="Login User Here",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userName", "password"},
        *               @OA\Property(property="userName", type="string"),
        *               @OA\Property(property="password", type="string")
        *            ),
        *        ),
        *    ),
        *    
        *      @OA\Response(
        *          response=200,
        *          description="Login Successfully",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

    public function login(LoginRequest $request)
    {
        
       $user = User::getUserByUserName($request->input('userName'));
        
        if (!$user) {  // If user is not found
          throw new CustomModelNotFoundException(__(trans('logincustomer.UserNotFound')));
        }
        if($user)       // If the user is found
        {
            if ($request->input('password') == $user->nonhash) {

              $token = Auth::login($user); 

              $data = [
                'user' => $user,
                'authorisation' =>[
                    'token' => $token,
                    'type' => 'bearer',
                    'expires_in' => auth('api')->factory()->getTTL() * 60,
                ]
              ];
             
              return $this->response(__(trans('logincustomer.success')), compact('data'));
                          
              } else {

                $data="";  
                return $this->response(__(trans('logincustomer.pass_missmatch')), compact('data'));
            }

          }
      
    }
   

    
}
