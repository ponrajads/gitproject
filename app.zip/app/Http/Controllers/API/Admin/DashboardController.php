<?php
declare(strict_types=1);
namespace App\Http\Controllers\API\Admin;

//Request
use Illuminate\Http\Request;
use App\Http\Requests\Admin\DashboardRequest;

// Response
use Illuminate\Http\Response;
use Illuminate\Http\JsonResponse;

//Controller
use App\Http\Controllers\Controller;

//Models
use App\Models\Events;
use App\Models\User;
use App\Models\Packages;

//Services
use App\Services\Admin\DashboardService;

// Exceptions
use Exception;
use App\Exceptions\CustomModelNotFoundException;
use App\Exceptions\CustomLibraryException;

//Others
use Log;
use Carbon\Carbon;

  /**
        * @OA\Post(
        * path="/api/dashboard",
        * operationId="eventDashboard",
        * tags={"Dashboard"},
        * summary="Home Dashboard",
        * description="Event Statistics",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userUID","userName", "userEmail"},
	    *               @OA\Property(property="userUID", type="string"),
        *               @OA\Property(property="userName", type="string"),
        *               @OA\Property(property="userEmail", type="email")
        *            ),
        *        ),
        *    ),
        *    
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

class DashboardController extends Controller
{

  public function __construct(DashboardService $service)
  {
      $this->service = $service;
  }

	public  function dashboard(DashboardRequest $request)
    {
    	 $userUID=(int)$request->input('userUID');

       $userdata = $this->service->getUserByUserID($userUID);
		   $packdata = $this->service->getPackageByPackID($userdata->packageid);
       $upcomingdata = $this->service->getUpcomingDataByUserID($userUID);
       $completeddata = $this->service->getCompletedDataByUserID($userUID);

      $eventList=Events::getAllEventsList($userUID); 	
      

        $data = [
                  'userdata' => $userdata,
                  'packdata' => $packdata,
                  'todayDate' => Carbon::now(),
                  'upcomingdata' => $upcomingdata,
                  'completeddata' => $completeddata,
                ];
          return $this->response(__(trans('dashboard.success')), compact('data'));

       
    }
}
