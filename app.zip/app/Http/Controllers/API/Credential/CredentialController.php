<?php
declare(strict_types=1);
namespace App\Http\Controllers\API\Credential;

//Request
use Illuminate\Http\Request;
use App\Http\Requests\Credential\CredentialRequest;

// Response
use Illuminate\Http\Response;
use Illuminate\Http\JsonResponse;

//Controller
use App\Http\Controllers\Controller;

//Services
use App\Services\Credential\CredentialService;

// Exceptions
use Exception;
use App\Exceptions\CustomModelNotFoundException;
use App\Exceptions\CustomLibraryException;

//Others
use Illuminate\Support\Facades\Auth;
use Validator;
use Hash;
use Log;
use Qrcode;


class CredentialController extends Controller
{
  public function __construct(CredentialService $service)
  {
      $this->service = $service;
  }

        /**
        * @OA\Post(
        * path="/api/registrationauth",
        * operationId="registrationAuth",
        * tags={"Create Registration Credentials"},
        * summary="Credentials",
        * description="Credentials",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userName","password","eventid","uid"},
	    *               @OA\Property(property="username", type="string"),
        *               @OA\Property(property="password", type="string"),
        *               @OA\Property(property="eventid", type="string"),
        *               @OA\Property(property="uid", type="string")
        *            ),
        *        ),
        *    ),
        *
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */


    public  function registrationAuth(CredentialRequest $request)
    {

         $events = $this->service->getUserByEventID((int)$request->input('eventid'));
         $result = substr($events->name, 0, 3);
         $username = $result."_".substr(md5(microtime()), 0, 10)."_".$request->input('username');

         $this->service->createAccount($request,$username,1);
          
         $data = [  ];
         return $this->response(__(trans('credential.credential_success')), compact('data'));

    }

    /**
        * @OA\Post(
        * path="/api/medicalauth",
        * operationId="medicalAuth",
        * tags={"Create Medical Credentials"},
        * summary="Credentials",
        * description="Credentials",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userName","password","eventid","uid"},
	      *               @OA\Property(property="username", type="string"),
        *               @OA\Property(property="password", type="string"),
        *               @OA\Property(property="eventid", type="string"),
        *               @OA\Property(property="uid", type="string")
        *            ),
        *        ),
        *    ),
        *
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

    public function medicalAuth(CredentialRequest $request)
    {
         $events = $this->service->getUserByEventID((int)$request->input('eventid'));
         $result = substr($events->name, 0, 3);
         $username = $result."_".substr(md5(microtime()), 0, 10)."_".$request->input('username');

         $this->service->createAccount($request,$username,2);
          
         $data = [  ];
         return $this->response(__(trans('credential.credential_success')), compact('data'));
    }

    /**
        * @OA\Post(
        * path="/api/callroomauth",
        * operationId="callroomAuth",
        * tags={"Create CallRoom Credentials"},
        * summary="Credentials",
        * description="Credentials",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userName","password","eventid","uid"},
	      *               @OA\Property(property="username", type="string"),
        *               @OA\Property(property="password", type="string"),
        *               @OA\Property(property="eventid", type="string"),
        *               @OA\Property(property="uid", type="string")
        *            ),
        *        ),
        *    ),
        *
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

    public function callroomAuth(CredentialRequest $request)
    {
         $events = $this->service->getUserByEventID((int)$request->input('eventid'));
         $result = substr($events->name, 0, 3);
         $username = $result."_".substr(md5(microtime()), 0, 10)."_".$request->input('username');

         $this->service->createAccount($request,$username,3);
          
         $data = [  ];
         return $this->response(__(trans('credential.credential_success')), compact('data'));
    }

     /**
        * @OA\Post(
        * path="/api/onfieldauth",
        * operationId="onfieldAuth",
        * tags={"Create OnField Credentials"},
        * summary="Credentials",
        * description="Credentials",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userName","password","eventid","uid"},
	      *               @OA\Property(property="username", type="string"),
        *               @OA\Property(property="password", type="string"),
        *               @OA\Property(property="eventid", type="string"),
        *               @OA\Property(property="uid", type="string")
        *            ),
        *        ),
        *    ),
        *
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

    public function onfieldAuth(CredentialRequest $request)
    {
      $events = $this->service->getUserByEventID((int)$request->input('eventid'));
      $result = substr($events->name, 0, 3);
      $username = $result."_".substr(md5(microtime()), 0, 10)."_".$request->input('username');

      $this->service->createAccount($request,$username,4);
       
      $data = [  ];
      return $this->response(__(trans('credential.credential_success')), compact('data'));
    }

     /**
        * @OA\Post(
        * path="/api/podiumauth",
        * operationId="podiumAuth",
        * tags={"Create Podium Credentials"},
        * summary="Credentials",
        * description="Credentials",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userName","password","eventid","uid"},
	      *               @OA\Property(property="username", type="string"),
        *               @OA\Property(property="password", type="string"),
        *               @OA\Property(property="eventid", type="string"),
        *               @OA\Property(property="uid", type="string")
        *            ),
        *        ),
        *    ),
        *
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

    public function podiumAuth(CredentialRequest $request)
    {
      $events = $this->service->getUserByEventID((int)$request->input('eventid'));
      $result = substr($events->name, 0, 3);
      $username = $result."_".substr(md5(microtime()), 0, 10)."_".$request->input('username');

      $this->service->createAccount($request,$username,5);
       
      $data = [  ];
      return $this->response(__(trans('credential.credential_success')), compact('data'));
    }

     /**
        * @OA\Post(
        * path="/api/foodcourtauth",
        * operationId="foodcourtAuth",
        * tags={"Create FoodCourt Credentials"},
        * summary="Credentials",
        * description="Credentials",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userName","password","eventid","uid"},
	      *               @OA\Property(property="username", type="string"),
        *               @OA\Property(property="password", type="string"),
        *               @OA\Property(property="eventid", type="string"),
        *               @OA\Property(property="uid", type="string")
        *            ),
        *        ),
        *    ),
        *
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

    public function foodcourtAuth(CredentialRequest $request)
    {
      $events = $this->service->getUserByEventID((int)$request->input('eventid'));
      $result = substr($events->name, 0, 3);
      $username = $result."_".substr(md5(microtime()), 0, 10)."_".$request->input('username');

      $this->service->createAccount($request,$username,6);
      
      $data = [  ];
      return $this->response(__(trans('credential.credential_success')), compact('data'));

    }

     /**
        * @OA\Post(
        * path="/api/complementaryauth",
        * operationId="complementaryAuth",
        * tags={"Create Complementary Credentials"},
        * summary="Credentials",
        * description="Credentials",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userName","password","eventid","uid"},
	      *               @OA\Property(property="username", type="string"),
        *               @OA\Property(property="password", type="string"),
        *               @OA\Property(property="eventid", type="string"),
        *               @OA\Property(property="uid", type="string")
        *            ),
        *        ),
        *    ),
        *
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

    public function complementaryAuth(CredentialRequest $request)
    {
      $events = $this->service->getUserByEventID((int)$request->input('eventid'));
      $result = substr($events->name, 0, 3);
      $username = $result."_".substr(md5(microtime()), 0, 10)."_".$request->input('username');

      $this->service->createAccount($request,$username,7);
      
      $data = [  ];
      return $this->response(__(trans('credential.credential_success')), compact('data'));

    }


}
