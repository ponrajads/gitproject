<?php
declare(strict_types=1);
namespace App\Http\Controllers\API\Event;

//Request
use Illuminate\Http\Request;
use App\Http\Requests\Event\EventRequest;
use App\Http\Requests\Event\EventDetailRequest;

// Response
use Illuminate\Http\Response;
use Illuminate\Http\JsonResponse;

//Controller
use App\Http\Controllers\Controller;

//Services
use App\Services\Event\EventService;

use App\Models\EventMaster;
// Exceptions
use Exception;
use App\Exceptions\CustomModelNotFoundException;
use App\Exceptions\CustomLibraryException;

//Others
use Carbon\Carbon;

class EventController extends Controller
{
	public function __construct(EventService $service)
	{
		$this->service = $service;
	}
    /**
        * @OA\Post(
        * path="/api/eventlist",
        * operationId="eventList",
        * tags={"Event List"},
        * summary="Event List",
        * description="List Event Details",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"userUID","userName", "userEmail"},
	    *               @OA\Property(property="userUID", type="string"),
        *               @OA\Property(property="userName", type="string"),
        *               @OA\Property(property="userEmail", type="email")
        *            ),
        *        ),
        *    ),
        *    
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

    public function eventList(EventRequest $request)
    {
    	
		$eventList=$this->service->getAllEventsList((int)$request->input('userUID')); 	

		$data = [
			'eventList' => $eventList,
			'eventCount' => COUNT($eventList),
			'todayDate' => Carbon::now(),
		  ];
		return $this->response(__(trans('event.success')), compact('data'));
		    
    }

	    /**
        * @OA\Post(
        * path="/api/eventdetail",
        * operationId="eventDetail",
        * tags={"Event Detail"},
        * summary="Event Detail",
        * description="Event Details",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"eventid"},
	    *               @OA\Property(property="eventid", type="number")
        *            ),
        *        ),
        *    ),
        *    
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */

	public function eventDetail(EventDetailRequest $request)
	{
        $eventid=(int)$request->input('eventid');
        $eventdata = $this->service->getEventByEventID($eventid);

        $registercredentials = $this->service->getCredentialsByEventID($eventid,1);
        $medicalcredentials = $this->service->getCredentialsByEventID($eventid,2);
        $callroomcredentials = $this->service->getCredentialsByEventID($eventid,3);
        $onfieldcredentials = $this->service->getCredentialsByEventID($eventid,4);
        $podiumcredentials = $this->service->getCredentialsByEventID($eventid,5);
        $foodcourtcredentials = $this->service->getCredentialsByEventID($eventid,6);
        $complementarycredentials = $this->service->getCredentialsByEventID($eventid,7);
	
        $regdata = $this->service->getRegDataByEventID($eventid);
		    $regabdata = $this->service->getRegAbscentDataByEventID($eventid);
		
		    $regabsdata = ($regabdata->playersid == '')?'': $this->service->getRegAbscentDataByPlayerID($eventid,$regabdata->playersid);

        $medicaldata = $this->service->getMedicalDataByEventID($eventid);
        $callroomdata = $this->service->getCallRoomDataByEventID($eventid);
        $onfielddata = $this->service->getOnFieldDataByEventID($eventid);
        $podiumdata = $this->service->getPodiumDataByEventID($eventid);
        $foodcourtdata = $this->service->getFoodCourtDataByEventID($eventid);
        $compdata = $this->service->getComplimentaryDataByEventID($eventid);

		$data = [
			'eventdata' => $eventdata,
			'registercredentials' => $registercredentials,
			'medicalcredentials' => $medicalcredentials,
			'callroomcredentials' => $callroomcredentials,
			'onfieldcredentials' => $onfieldcredentials,
			'podiumcredentials' => $podiumcredentials,
			'foodcourtcredentials' => $foodcourtcredentials,
			'complementarycredentials' => $complementarycredentials,
			'regplayerlist' => $regdata,
			'regabsentlist' => $regabsdata,
			'medplayerlist' => $medicaldata,
			'callroomdata' => $callroomdata,
			'onfielddata' => $onfielddata,
			'podiumdata' => $podiumdata,
			'foodcourtdata' => $foodcourtdata,
			'compdata' => $compdata,
		];
		return $this->response(__(trans('event.success')), compact('data'));
    }

	public function createEvent(Request $request)
  {
		$userdata = $this->service->getUserByUserID((int)$request->input('uid'));
		if($userdata->eventcount == 0)
		{
      throw new CustomModelNotFoundException(__(trans('logincustomer.UserNotFound')));
    }
			$eventlogo= $request->file('eventlogo');
			$destinationPath = storage_path('app/public/data/eventlogo');
			$eventlogo_name = 'Players_list'.time().'.'.$eventlogo->getClientOriginalExtension();
			$eventlogo->move($destinationPath, $eventlogo_name);

			$this->service->createEventByRequest($request,$eventlogo_name,$userdata);
			$data =[]; 
      return $this->response(__(trans('event.success')), compact('data'));
				
    }
	    /**
        * @OA\Post(
        * path="/api/listevent-category",
        * operationId="listEventCategory",
        * tags={"Event List"},
        * summary="Event List",
        * description="Event List",
        *     @OA\RequestBody(
        *         @OA\JsonContent(),
        *         @OA\MediaType(
        *            mediaType="multipart/form-data",
        *            @OA\Schema(
        *               type="object",
        *               required={"eventid"},
	    *               @OA\Property(property="eventid", type="number")
        *            ),
        *        ),
        *    ),
        *    
        *      @OA\Response(
        *          response=200,
        *          description="Success",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(
        *          response=422,
        *          description="Unprocessable Entity",
        *          @OA\JsonContent()
        *       ),
        *      @OA\Response(response=400, description="Bad request"),
        *      @OA\Response(response=404, description="Resource Not Found"),
        * )
        */


	public function listEventCategory(EventDetailRequest $request){
		
		$eventdata = $this->service->getAllEvents();

		$data = [
			'eventcategorylist' => $eventdata,
		  ];
		return $this->response(__(trans('event.eventlist_success')), compact('data'));
}
}
