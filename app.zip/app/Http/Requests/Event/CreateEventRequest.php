<?php
declare(strict_types=1);
namespace App\Http\Requests\Event;

// Request
use App\Http\Requests\BaseRequest;
use Illuminate\Foundation\Http\FormRequest;


class CreateEventReuest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
 public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
 public function rules()
    {
		 return  [
            'eventlogo' =>  'required',
            'uid'  =>  'required',
            'eventName' => 'required|string|max:255',
            'userEmail' => 'required|string|min:6|max:255',
            ];
    }
	
 public function messages()
    {
        return [
           'eventid.required' => __('event.eventid.required'),
		   'eventid.int' => __('event.eventid.int'),
         
        ];
    }

    
}


