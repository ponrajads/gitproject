<?php
declare(strict_types=1);
namespace App\Http\Requests\Event;

// Request
use App\Http\Requests\BaseRequest;
use Illuminate\Foundation\Http\FormRequest;


class EventRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
 public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
 public function rules()
    {
		 return  [
            'userUID'  =>  'required',
            'userName' => 'required|string|max:255',
            'userEmail' => 'required|string|min:6|max:255',
            ];
    }
	
 public function messages()
    {
        return [
           'userUID.required' => __('event.userUID.required'),
		   'userName.required' => __('event.userName.required'),
           'userName.string' => __('event.userName.string'),
           'userName.max' => __('event.userName.max'),
		   'userEmail.required' => __('event.email.required'),
           'userEmail.string' => __('event.email.string'),
           'userEmail.min' => __('event.email.min'),
           'userEmail.max' => __('event.email.max'),
        ];
    }

    
}


