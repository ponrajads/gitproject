<?php
declare(strict_types=1);
namespace App\Http\Requests\Admin;

// Request
use App\Http\Requests\BaseRequest;
use Illuminate\Foundation\Http\FormRequest;


class DashboardRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
		 return  [
            'userUID'  =>  'required',
            'userName' => 'required|string|max:255',
            'userEmail' => 'required|string|min:6|max:255',
            ];
    }
	
    public function messages()
    {
        return [
           'userUID.required' => __('dashboard.userUID.required'),
		   'userName.required' => __('dashboard.userName.required'),
           'userName.string' => __('dashboard.userName.string'),
           'userName.max' => __('dashboard.userName.max'),
		   'userEmail.required' => __('dashboard.email.required'),
           'userEmail.string' => __('dashboard.email.string'),
           'userEmail.min' => __('dashboard.email.min'),
           'userEmail.max' => __('dashboard.email.max'),
        ];
    }

    
}


