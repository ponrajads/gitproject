<?php
declare(strict_types=1);
namespace App\Http\Requests\Credential;

// Request
use App\Http\Requests\BaseRequest;
use Illuminate\Foundation\Http\FormRequest;


class CredentialRequest extends BaseRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
		 return  [

            'username' => 'required|string|max:255',
            'password' => 'required|string|min:6|max:255',
            'eventid'  => 'required|string|max:255',
            'uid'      => 'required|string|max:255',
            ];
    }

 public function messages()
    {
        return [
	       'username.required' => __('credential.username.required'),
           'username.string' => __('credential.username.string'),
           'username.max' => __('credential.username.max'),
		   'password.required' => __('credential.password.required'),
           'password.string' => __('credential.password.string'),
           'password.min' => __('credential.password.min'),
           'password.max' => __('credential.password.max'),
           'eventid.required' => __('credential.eventid.required'),
           'uid.required' => __('credential.uid.required'),
        ];
    }


}


